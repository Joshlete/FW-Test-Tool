from PySide6.QtWidgets import QFrame, QHBoxLayout, QLabel, QPushButton
from PySide6.QtCore import Qt, Signal

class AlertCard(QFrame):
    """
    A compact single-line card widget representing a single alert.
    """
    # Emits alert ID and the action value (e.g., "acknowledge", "continue")
    action_requested = Signal(str, str)
    # Emits full alert data dictionary when right-clicked
    context_menu_requested = Signal(dict)

    # Map raw color names to Hex for Sirius compatibility
    RAW_COLOR_MAP = {
        "black": "#000000",
        "yellow": "#FFD700",
        "cyan": "#87CEEB",
        "magenta": "#FF00FF",
        "tri-color": "#CD5C5C", # IndianRed as a placeholder for tri-color
    }

    def _get_supply_color(self, alert_data):
        """
        Extracts supply color from iValue in alert data or raw_color field.
        Returns hex color string or None if not found/applicable.
        """
        # 1. Check Sirius 'raw_color' first
        raw_color = alert_data.get('raw_color', '')
        if raw_color:
            return self.RAW_COLOR_MAP.get(str(raw_color).lower(), None)

        # 2. Check Ares/Dune 'data' list for iValue
        # Map iValues to Colors (CMYK)
        COLOR_MAP = {
            101: "#000000", # Black
            102: "#FFD700", # Yellow
            103: "#87CEEB", # Sky Blue
            104: "#FF00FF", # Magenta
        }

        try:
            data_list = alert_data.get('data', [])
            for item in data_list:
                # Check if this data item relates to supplies
                if 'suppliesPublic' in item.get('resourceGun', ''):
                    val = item.get('value', {}).get('iValue')
                    if val in COLOR_MAP:
                        return COLOR_MAP[val]
        except:
            pass
        
        return None

    def __init__(self, alert_data, parent=None):
        super().__init__(parent)
        self.alert_data = alert_data
        self.alert_id = str(alert_data.get('id'))
        
        self.setObjectName("AlertCard")
        # Severity determines the border color
        severity = str(alert_data.get('severity', 'info')).lower()
        
        # Determine Indicator Color (Supply vs Severity)
        severity_color = self._get_color(severity)
        supply_color = self._get_supply_color(alert_data)
        indicator_color = supply_color if supply_color else severity_color
        
        self._set_severity_style(severity)
        self.setFixedHeight(46) # Force single line height

        # --- Layout ---
        layout = QHBoxLayout(self)
        layout.setContentsMargins(10, 5, 10, 5) # Tighter margins
        layout.setSpacing(12)

        # --- Icon / Severity Indicator (Left) ---
        self.indicator = QLabel()
        self.indicator.setFixedWidth(4)
        self.indicator.setStyleSheet(f"background-color: {indicator_color}; border-radius: 2px; border: 1px solid rgba(255, 255, 255, 0.3);")
        layout.addWidget(self.indicator)

        # --- Title (String ID) ---
        title_text = str(alert_data.get('stringId', 'Unknown Alert'))
        self.title = QLabel(title_text)
        self.title.setObjectName("CardTitle")
        layout.addWidget(self.title)
        
        # --- Badges (Extra Bubbles) ---
        # Support a list of 'badges' in alert_data to display as bubbles next to title
        badges = alert_data.get('badges', [])
        for badge_text in badges:
            if badge_text:
                badge = QLabel(str(badge_text))
                badge.setObjectName("CardBadge")
                layout.addWidget(badge)

        # --- Info (Category) ---
        cat = alert_data.get('category', 'General')
        self.info = QLabel(cat)
        self.info.setObjectName("CardInfo")
        layout.addWidget(self.info)
        
        # --- Priority Bubble ---
        pri = alert_data.get('priority', '')
        if pri:
            pri_lbl = QLabel(f"Priority: {pri}")
            pri_lbl.setObjectName("CardBadge")
            layout.addWidget(pri_lbl)
        
        layout.addStretch(1) # Push actions to the right

        # --- Actions (Right) ---
        actions = alert_data.get('actions', {})
        if 'supported' in actions:
            for action in actions['supported']:
                action_value = action.get('value', {}).get('seValue')
                if action_value:
                    # Create button for this action
                    btn = QPushButton(action_value.capitalize().replace('_', ' '))
                    btn.setCursor(Qt.CursorShape.PointingHandCursor)
                    btn.setObjectName("CardAction")
                    btn.clicked.connect(lambda checked=False, av=action_value: self._on_action_clicked(av))
                    layout.addWidget(btn)

    def _on_action_clicked(self, action_value):
        self.action_requested.emit(self.alert_id, action_value)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.RightButton:
            self.context_menu_requested.emit(self.alert_data)
        super().mousePressEvent(event)

    def _get_color(self, severity):
        """Return hex color for severity."""
        if 'critical' in severity or 'error' in severity:
            return "#FF5252" # Red
        if 'warning' in severity:
            return "#FFAB40" # Orange
        return "#448AFF" # Blue (Info)

    def _set_severity_style(self, severity):
        # Main Card Style
        # Handled by AlertCard ID in dark_theme.qss
        pass
